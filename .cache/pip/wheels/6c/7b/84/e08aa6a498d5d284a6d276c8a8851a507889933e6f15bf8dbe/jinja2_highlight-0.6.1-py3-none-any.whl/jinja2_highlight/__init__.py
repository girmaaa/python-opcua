# -*- coding: utf8 -*-
from .highlight import HighlightExtension
